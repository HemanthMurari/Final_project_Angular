// import {Car} from "./car.model";

export class Employee {
  id: number | undefined;
 name: string | undefined; 

}